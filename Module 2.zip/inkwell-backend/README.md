# Inkwell — Backend (Module 2)

A Node.js + Express REST API backend for the Inkwell blog app, plus the
original frontend rewired to talk to it instead of `localStorage`.

## What's inside

- **Node.js + Express server** (`server.js`) that also serves the frontend
  as static files, so everything runs from one origin/port.
- **REST APIs**:
  - `POST /api/auth/register` — create an account
  - `POST /api/auth/login` — log in
  - `GET  /api/auth/me` — get the logged-in user (requires auth)
  - `GET  /api/posts` — list all blog posts
  - `GET  /api/posts/:id` — get one post
  - `POST /api/posts` — create a post (requires auth)
  - `PUT  /api/posts/:id` — edit your own post (requires auth)
  - `DELETE /api/posts/:id` — delete your own post (requires auth)
- **JSON-file storage** (`data/db.json`, created automatically on first run)
  with passwords hashed via `bcryptjs` and sessions handled with JWTs
  (`jsonwebtoken`).
- **Frontend** (`public/`) — the original Inkwell HTML/CSS, with
  `js/app.js`, `js/auth.js`, and `js/blog.js` updated to call the API via
  `fetch` instead of reading/writing `localStorage` directly. The
  logged-in user's JWT is cached in `localStorage` under `inkwell_session`
  so the UI knows who's logged in without an extra network call.

## Setup

```bash
cd inkwell-backend
npm install
cp .env.example .env   # optional — edit JWT_SECRET for real use
npm start
```

Then open **http://localhost:3000** in your browser.

A seed account is created automatically the first time the server runs:

- email: `mara@inkwell.dev`
- password: `password123`

## How the pieces connect

- `middleware/auth.js` verifies the `Authorization: Bearer <token>` header
  on protected routes and issues new JWTs on register/login.
- `utils/db.js` reads/writes `data/db.json` — swap this for a real database
  (MongoDB, PostgreSQL, etc.) later without touching the routes' logic much.
- `routes/auth.js` and `routes/posts.js` hold the REST endpoints.
- `public/js/app.js` exports a small `apiFetch()` helper plus
  `getPosts`, `createPost`, `updatePost`, `deletePost`, `loginUser`,
  `registerUser` — all `async` functions that call the API.
- `public/js/auth.js` and `public/js/blog.js` call those instead of the old
  `localStorage`-based `getUsers`/`saveUsers`/`getPosts`/`savePosts`.

## Notes

- This sandbox has no network access, so dependencies couldn't be installed
  or the server run end-to-end here — all files were syntax-checked with
  `node --check`. Run `npm install && npm start` locally to try it.
- For a production deployment, set a real `JWT_SECRET` in `.env` and swap
  the JSON-file store for a proper database.
