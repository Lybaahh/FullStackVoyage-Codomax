@echo off
cd /d "%~dp0"
echo Starting Inkwell server...
echo.
echo Once you see "Inkwell server running at http://localhost:3000",
echo open your browser and go to: http://localhost:3000
echo.
echo Keep this window open while using the site.
echo Press Ctrl+C here (or just close this window) to stop the server.
echo.
npm start
pause
